create function obtenerexcento(idcontrato integer) returns boolean
LANGUAGE SQL
AS $$
select exentoiva
 from
   tipocontrato 
 where 
   id=idcontrato
$$;
