create function obteneriva() returns double precision
LANGUAGE SQL
AS $$
select valoractual
 from
   impuestos 
 where 
   nombre='IVA'
$$;
