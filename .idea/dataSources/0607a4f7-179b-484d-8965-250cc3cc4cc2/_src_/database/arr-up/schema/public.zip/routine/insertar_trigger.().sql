create function insertar_trigger() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO auditoria.auditoria VALUES (old.codigo, old.nombre,old.apellido,now(),USER);
  RETURN NULL;
END;
$$;
